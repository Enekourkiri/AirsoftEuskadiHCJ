-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 15-02-2018 a las 11:33:24
-- Versión del servidor: 10.0.33-MariaDB-0ubuntu0.16.04.1
-- Versión de PHP: 7.0.25-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `WORDPRESS`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `wp_armas`
--

CREATE TABLE `wp_armas` (
  `Nombre` varchar(20) DEFAULT NULL,
  `Tipo` varchar(20) DEFAULT NULL,
  `Precio` decimal(5,2) DEFAULT NULL,
  `Disponible` varchar(20) DEFAULT NULL,
  `Armaid` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `wp_armas`
--

INSERT INTO `wp_armas` (`Nombre`, `Tipo`, `Precio`, `Disponible`, `Armaid`) VALUES
('Jericho', 'Pistola', '75.00', 'Si', 2),
('CZ-75D', 'Pistola', '75.00', 'Si', 3),
('G1911', 'Pistola', '70.00', 'No', 4),
('G11', 'Pistola', '75.00', 'Si', 5),
('Makarov', 'Pistola', '18.95', 'No', 6),
('G6D', 'Pistola', '22.95', 'Si', 7),
('Ruger MK1', 'Pistola', '54.99', 'Si', 8),
('P3G1', 'Pistola', '13.77', 'Si', 9),
('JG068MG', 'Subfusil', '116.90', 'No', 10),
('Model P5K', 'Subfusil', '160.16', 'No', 11),
('R4', 'Subfusil', '77.69', 'Si', 12),
('JG0452', 'Subfusil', '105.02', 'No', 13),
('D2811', 'Subfusil', '98.97', 'Si', 14),
('Apache SMG', 'Subfusil', '331.03', 'Si', 15),
('R2C', 'Subfusil', '79.40', 'Si', 16),
('MSD', 'Fusil de Asalto', '354.13', 'No', 17),
('JG1538', 'Fusil de Asalto', '192.51', 'No', 18),
('JG110', 'Fusil de Asalto', '183.78', 'No', 19),
('JG513MG', 'Fusil de Asalto', '116.66', 'Si', 20),
('CM032C', 'Fusil de Asalto', '306.27', 'No', 21),
('GKM', 'Fusil de Asalto', '492.15', 'No', 22),
('GR4 FF26', 'Fusil de Asalto', '262.02', 'Si', 23),
('TR15', 'Fusil de Asalto', '429.33', 'Si', 24),
('M3 90', 'Escopeta', '50.00', 'Si', 25),
('M3 90 Largo', 'Escopeta', '54.99', 'Si', 26),
('M3 92', 'Escopeta', '54.99', 'No', 27),
('GFG 25', 'Escopeta', '65.00', 'Si', 28),
('ZM61', 'Escopeta', '38.11', 'No', 29),
('CM351', 'Escopeta', '50.30', 'No', 30),
('CM350MN', 'Escopeta', '108.59', 'Si', 31),
('CM352', 'Escopeta', '75.46', 'No', 32),
('SVD', 'Francotirador', '215.00', 'Si', 33),
('SL 9', 'Francotirador', '270.00', 'Si', 34),
('SPR', 'Francotirador', '255.00', 'Si', 35),
('M24', 'Francotirador', '120.00', 'Si', 36),
('AK 47', 'Fusil de Asalto', '150.00', 'Si', 37);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `wp_armas`
--
ALTER TABLE `wp_armas`
  ADD PRIMARY KEY (`Armaid`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `wp_armas`
--
ALTER TABLE `wp_armas`
  MODIFY `Armaid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
