-- MySQL dump 10.15  Distrib 10.0.33-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: airsoft2
-- ------------------------------------------------------
-- Server version	10.0.33-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Armas2`
--

DROP TABLE IF EXISTS `Armas2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Armas2` (
  `Nombre` varchar(20) DEFAULT NULL,
  `Tipo` varchar(20) DEFAULT NULL,
  `Precio` decimal(5,2) DEFAULT NULL,
  `Disponible` varchar(20) DEFAULT NULL,
  `Armaid` int(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Armaid`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Armas2`
--

LOCK TABLES `Armas2` WRITE;
/*!40000 ALTER TABLE `Armas2` DISABLE KEYS */;
INSERT INTO `Armas2` VALUES ('Jericho','Pistola',75.00,'Si',2),('CZ-75D','Pistola',75.00,'Si',3),('G1911','Pistola',70.00,'No',4),('G11','Pistola',75.00,'Si',5),('Makarov','Pistola',18.95,'No',6),('G6D','Pistola',22.95,'Si',7),('Ruger MK1','Pistola',54.99,'Si',8),('P3G1','Pistola',13.77,'Si',9),('JG068MG','Subfusil',116.90,'No',10),('Model P5K','Subfusil',160.16,'No',11),('R4','Subfusil',77.69,'Si',12),('JG0452','Subfusil',105.02,'No',13),('D2811','Subfusil',98.97,'Si',14),('Apache SMG','Subfusil',331.03,'Si',15),('R2C','Subfusil',79.40,'Si',16),('MSD','Fusil de Asalto',354.13,'No',17),('JG1538','Fusil de Asalto',192.51,'No',18),('JG110','Fusil de Asalto',183.78,'No',19),('JG513MG','Fusil de Asalto',116.66,'Si',20),('CM032C','Fusil de Asalto',306.27,'No',21),('GKM','Fusil de Asalto',492.15,'No',22),('GR4 FF26','Fusil de Asalto',262.02,'Si',23),('TR15','Fusil de Asalto',429.33,'Si',24),('M3 90','Escopeta',50.00,'Si',25),('M3 90 Largo','Escopeta',54.99,'Si',26),('M3 92','Escopeta',54.99,'No',27),('GFG 25','Escopeta',65.00,'Si',28),('ZM61','Escopeta',38.11,'No',29),('CM351','Escopeta',50.30,'No',30),('CM350MN','Escopeta',108.59,'Si',31),('CM352','Escopeta',75.46,'No',32),('SVD','Francotirador',215.00,'Si',33),('SL 9','Francotirador',270.00,'Si',34),('SPR','Francotirador',255.00,'Si',35),('M24','Francotirador',120.00,'Si',36),('AK 47','Fusil de Asalto',150.00,'Si',37);
/*!40000 ALTER TABLE `Armas2` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-25 11:06:01
